class Split {
  const Split({this.km, this.pace, this.elev});
  final int km;
  final Duration pace;
  final int elev;
}
