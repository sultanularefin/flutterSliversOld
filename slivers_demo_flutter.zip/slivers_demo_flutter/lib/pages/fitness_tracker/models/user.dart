class User {
  const User({this.displayName, this.username, this.photoUrl});
  final String displayName;
  final String username;
  final String photoUrl;
}
